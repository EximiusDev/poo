#include <iostream>
using namespace std;

class Mascota {
	string m_nombre, m_especie;
public:
	Mascota(string nom, string esp) {
		m_nombre = nom; m_especie = esp;
	}
	string VerNombre() const { return m_nombre; }
	string VerEspecie() const { return m_especie; }
};

class Perro : public Mascota {
	string m_raza;
public:
	Perro(string nom, string raza) : Mascota(nom,"Perro") {
		m_raza = raza;
	}
	string Ladrar() const { return "Guau!!"; }
};

int main() {
	Perro p("Enviado de Santa","Galgo");
	cout << p.VerNombre() << endl;
	cout << p.Ladrar() << endl;
	return 0;
}

