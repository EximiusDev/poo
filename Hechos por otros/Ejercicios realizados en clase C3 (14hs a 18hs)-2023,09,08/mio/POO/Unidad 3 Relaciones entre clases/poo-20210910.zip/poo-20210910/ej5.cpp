#include <iostream>
#include <cmath>
#include <vector>
using namespace std;


class Monomio {
public:
	Monomio(int grado, float coef) : m_grado(grado), m_coef(coef) { }
	float VerCoef() const { return m_coef; }
	float VerGrado() const { return m_grado; }
	float Evaluar(float x) const { return m_coef*pow(x,m_grado); }
private:
	int m_grado;
	float m_coef;
};


class Polinomio {
public:
	Polinomio(int grado) : m_v(grado+1,Monomio(0,0)) {	}
	void CargarCoef(int grado, float coef) { m_v[grado] = Monomio(grado,coef); }
	int VerGrado() const { return m_v.size()-1; }
	float VerCoef(int grado) const { return m_v[grado].VerCoef(); }
	float Evaluar(float x) const {
		float sum = 0;
		for(const Monomio &m : m_v)
			sum += m.Evaluar(x);
		return sum;
	}
private:
	vector<Monomio> m_v;
};

void mostrar(Polinomio p) {
	cout << "p(x) = ";
	for (int i=0; i<=p.VerGrado(); ++i) {
		if (i!=0 and p.VerCoef(i)>=0) cout << '+';
		cout << p.VerCoef(i) << "*x^" << i << ' ' ;
	}
	cout << endl;
}

int main() {
	int grado;
	cout << "Grado:";
	cin >> grado;
	Polinomio p(grado);
	
	for (int i=0; i<=p.VerGrado(); ++i) { 
		cout << "Coef grado " << i << ":";
		float c;
		cin >> c;
		p.CargarCoef(i,c);
		mostrar(p);
	}
	
	
	float x; 
	cout << "x=";
	cin >> x;
	cout << "p("<<x<<") = " << p.Evaluar(x) << endl;
	
	return 0;
}

