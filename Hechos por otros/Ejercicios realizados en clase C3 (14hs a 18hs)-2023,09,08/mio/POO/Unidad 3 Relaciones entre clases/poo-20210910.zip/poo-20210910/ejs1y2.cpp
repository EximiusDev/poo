#include <iostream>
#include <vector>
using namespace std;

struct Fecha { int d,m,a; };

int diffAnios(Fecha f1, Fecha f2) {
	int i1 = f1.a*10000+f1.m*100+f1.d;
	int i2 = f2.a*10000+f2.m*100+f2.d;
	return (i2-i1)/10000;
}

class Persona {
public:
	Persona(string ape, string nom, int dni, Fecha fnac) 
		: m_ape(ape), m_nom(nom), m_dni(dni), m_fnac(fnac), m_ec('s') { }
	
	void CambiarEstadoCivil(char ec) { m_ec = ec; }
	
	string VerNombre() const { return m_nom; }
	string VerApellido() const { return m_ape; }
	int VerDNI() const { return m_dni; }
	char VerEstadoCivil() const { return m_ec; }
	Fecha VerFechaNacimiento() const { return m_fnac; }
	
	int CalcEdad(Fecha fact) const { return diffAnios(m_fnac,fact); }

private:
	string m_ape, m_nom;
	int m_dni;
	Fecha m_fnac;
	char m_ec;
};

class Alumno : public Persona {
	float m_prom;
	int m_mat;
public:
	Alumno(string ape, string nom, int dni, Fecha fnac, float prom, int mat)
		: Persona(ape,nom,dni,fnac), m_prom(prom), m_mat(mat) { }
	float VerPromedio() const { return m_prom; }
	int VerMatAprob() const { return m_mat; }
	float MeritoAcademico() const {
		return m_prom*m_mat;
	}
};

class Docente: public Persona {
	Fecha m_ing;
public:
	Docente(string ape, string nom, int dni, Fecha fnac, Fecha fing)
		: Persona(ape,nom,dni,fnac), m_ing(fing) { }
	Fecha VerFechaIngreso() const { return m_ing; }
	int CalcAntiguedad(Fecha fact) const { return diffAnios(m_ing,fact); }
};

class Curso {
	string m_mat;
	Docente m_d;
	vector<Alumno> m_va;
public:
	Curso(string mat, Docente d) : m_mat(mat), m_d(d) { }
	void AgregarAlumno(Alumno a) { m_va.push_back(a); }
	float MejorProm() const { ... }
};

int main() {
	
	Curso c("POO", Docente("Pablo","Novara",3333333,{33,33,33},{33,33,33}) );
	c.AgregarAlumno(Alumno("Perez","Juan",40657483,{10,9,2000}, 9.0,15));
	return 0;
}

