#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <cstring>
#include <list>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

int main(int argc, char *argv[]) {
	
	cout << "dijo: " << *argv[1];
	
	return 0;
}

