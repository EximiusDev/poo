// programado a lo besta: datos y operaciones en el main 

#include <iostream>
#include <cstring>
using namespace std;

int main(int argc, char *argv[]) {
	
	// datos
	int notas[100];
	int cant_notas;
	char nombre[256];
	char apellido[256];
	float prom;
	
	// cargar datos personales
	char aux1[256],aux2[256];
	cout<<"Ingrese el apellido: ";
	cin.getline(aux1,256);
	strcpy(apellido,aux1);
	cout<<"Ingrese el nombre: ";
	cin.getline(aux2,256);
	strcpy(nombre,aux2);
	
	// cargar las notas
	int nota;
	cout<<"Ingrese una nota, 0 para terminar: ";
	cin>>nota;
	cant_notas=0;
	while (nota!=0) {
		notas[cant_notas]=nota;
		cant_notas++;
		cout<<"Ingrese otra nota, 0 para terminar: ";
		cin>>nota;
	}
	
	// calcular el promedio
	float sum=0;
	for (int i=0;i<cant_notas;i++) {
		sum+=notas[i];
	}
	prom=sum/cant_notas;
	
	// mostrar el promedio
	cout<<"El promedio de "<<nombre<<" "<<apellido<<" es: "<<prom<<endl;
	
	return 0;
}

