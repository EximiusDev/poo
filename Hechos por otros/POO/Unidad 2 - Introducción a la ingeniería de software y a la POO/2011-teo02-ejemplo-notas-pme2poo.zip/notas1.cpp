// mejora 1: datos en un struct

#include <iostream>
#include <cstring>
using namespace std;

struct Alumno {
	int notas[100];
	int cant_notas;
	char nombre[256];
	char apellido[256];
	float prom;
};

int main(int argc, char *argv[]) {
	
	Alumno a;
	
	// cargar datos personales
	char aux1[256],aux2[256];
	cout<<"Ingrese el apellido: ";
	cin.getline(aux1,256);
	strcpy(a.apellido,aux1);
	cout<<"Ingrese el nombre: ";
	cin.getline(aux2,256);
	strcpy(a.nombre,aux2);
	
	// cargar las notas
	int nota;
	cout<<"Ingrese una nota, 0 para terminar: ";
	cin>>nota;
	a.cant_notas=0;
	while (nota!=0) {
		a.notas[a.cant_notas]=nota;
		a.cant_notas++;
		cout<<"Ingrese otra nota, 0 para terminar: ";
		cin>>nota;
	}
	
	// calcular el promedio
	float sum=0;
	for (int i=0;i<a.cant_notas;i++) {
		sum+=a.notas[i];
	}
	a.prom=sum/a.cant_notas;
	
	// mostrar el promedio
	cout<<"El promedio de "<<a.nombre<<" "<<a.apellido<<" es: "<<a.prom<<endl;
	
	return 0;
}

