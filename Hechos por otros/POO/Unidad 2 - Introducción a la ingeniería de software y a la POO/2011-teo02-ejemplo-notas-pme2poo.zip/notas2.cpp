// Ejemplo PME
// mejora 1: datos en un struct
// mejora 2: operaciones en funciones 

#include <iostream>
#include <cstring>
using namespace std;

struct Alumno {
	int notas[100];
	int cant_notas;
	char nombre[256];
	char apellido[256];
	float prom;
};

void inicializar_alumno(Alumno &a, char *nom, char *ape) {
	strcpy(a.nombre,nom);
	strcpy(a.apellido,ape);
	a.cant_notas=0;
}

void agregar_una_nota(Alumno &a, int n) {
	a.notas[a.cant_notas]=n;
	a.cant_notas++;
}

void calcular_promedio(Alumno &a) {
	float sum=0;
	for (int i=0;i<a.cant_notas;i++) {
		sum+=a.notas[i];
	}
	a.prom=sum/a.cant_notas;
}

int main(int argc, char *argv[]) {
	
	Alumno a;
	
	// cargar datos personales
	char aux1[256], aux2[256];
	cout<<"Ingrese el apellido: ";
	cin.getline(aux1,256);
	cout<<"Ingrese el nombre: ";
	cin.getline(aux2,256);
	inicializar_alumno(a,aux2,aux1);
	
	// cargar las notas
	int nota;
	cout<<"Ingrese una nota, 0 para terminar: ";
	cin>>nota;
	a.cant_notas=0;
	while (nota!=0) {
		agregar_una_nota(a,nota);
		cout<<"Ingrese otra nota, 0 para terminar: ";
		cin>>nota;
	}
	
	// calcular el promedio
	calcular_promedio(a);
	
	// mostrar el promedio
	cout<<"El promedio de "<<a.nombre<<" "<<a.apellido<<" es: "<<a.prom<<endl;
	
	return 0;
}

