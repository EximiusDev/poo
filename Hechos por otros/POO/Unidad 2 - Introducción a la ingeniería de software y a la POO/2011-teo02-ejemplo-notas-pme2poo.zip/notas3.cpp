// mejora 3: funciones como miembro del struct

#include <iostream>
#include <cstring>
using namespace std;

struct Alumno {
	int notas[100];
	int cant_notas;
	char nombre[256];
	char apellido[256];
	float prom;
	void inicializar(char *nom, char *ape) {
		strcpy(nombre,nom);
		strcpy(apellido,ape);
		cant_notas=0;
	}
	void agregar_una_nota(int n) {
		notas[cant_notas]=n;
		cant_notas++;
	}
	void calcular_promedio() {
		float sum=0;
		for (int i=0;i<cant_notas;i++) {
			sum+=notas[i];
		}
		prom=sum/cant_notas;
	}
};



int main(int argc, char *argv[]) {
	
	Alumno a;
	
	// cargar datos personales
	char aux1[256], aux2[256];
	cout<<"Ingrese el apellido: ";
	cin.getline(aux1,256);
	cout<<"Ingrese el nombre: ";
	cin.getline(aux2,256);
	a.inicializar(aux2,aux1);
	
	// cargar las notas
	int nota;
	cout<<"Ingrese una nota, 0 para terminar: ";
	cin>>nota;
	a.cant_notas=0;
	while (nota!=0) {
		a.agregar_una_nota(nota);
		cout<<"Ingrese otra nota, 0 para terminar: ";
		cin>>nota;
	}
	
	// calcular el promedio
	a.calcular_promedio();
	
	// mostrar el promedio
	cout<<"El promedio de "<<a.nombre<<" "<<a.apellido<<" es: "<<a.prom<<endl;
	
	return 0;
}

