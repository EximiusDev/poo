#include "Hormiga.h"
#include <cstdlib>
using namespace std;

// variables estaticas (las mismas para todas las hormigas) que mantienen los limites de la pantalla
int Hormiga::max_x=10,Hormiga::max_y=10;

// crea una hormiga en una posici�n dada y con un color dado
Hormiga::Hormiga(int x, int y, bool r) {
	pos_x=x; pos_y=y; roja=r;
	dir=rand()%4+1; 
}

// crea una hormiga de color aleatorio ubicada en una posici�n aleatoria
Hormiga::Hormiga() {
	pos_x=rand()%max_x+1; pos_y=rand()%max_y+1;
	dir=rand()%4+1; roja=rand()%2;
}

// m�todo para que la hormiga cambie de direccion al azar
void Hormiga::CambiaDireccion() {
	dir=rand()%4+1;
}

// m�todo que hace que la hormiga avance
void Hormiga::CaminaDerecho() {
	switch (dir) { // cambian las coordenadas segun para donde camina 
	case 1: pos_y--; break;
	case 2: pos_y++; break;
	case 3: pos_x++; break;
	case 4: pos_x--; break;
	}
	// controlar que no se salga de los limites (si se acaba de salir la volvemos a traer dentro)
	if (pos_x<1) pos_x=1;
	if (pos_y<1) pos_y=1;
	if (pos_x>max_x) pos_x=max_x;
	if (pos_y>max_y) pos_y=max_y;
}

// selectores: m�todos para "preguntarle" sus datos a la hormiga
int Hormiga::VerPosX() { return pos_x; }
int Hormiga::VerPosY() { return pos_y; }
int Hormiga::VerDir() { return dir; }
bool Hormiga::EsRoja() { return roja; }

// m�todo para definir los limites de la pantalla para toda la colonia de hormigas
void Hormiga::DefinirMaximos(int mx, int my) {
	max_x=mx; max_y=my;
}
