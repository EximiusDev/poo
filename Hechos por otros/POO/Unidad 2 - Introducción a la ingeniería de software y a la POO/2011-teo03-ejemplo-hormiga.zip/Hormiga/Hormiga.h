#ifndef HORMIGA_H
#define HORMIGA_H

/// Clase que representa a una hormiga
class Hormiga {
	int pos_x, pos_y; ///< ubicacion de la hormiga
	char dir; ///< 1=arriba, 2=abajo, 3=derecha, 4=iquierda
	bool roja; ///< true=roja, false=negra
	static int max_x, max_y; ///< tama�o de la grilla donde caminan las hormigas (para todas igual)
public:
	Hormiga(); ///< genera una hormiga al azar (ctor nulo necesario para amar un arreglo din�mico)
	Hormiga(int x, int y, bool r); ///< crea una hormiga del color indicado en la posicion indicada
	void CambiaDireccion(); ///< cambia de direccion al azar
	void CaminaDerecho(); ///< avanza un paso en la direccion que trae
	int VerPosX(); ///< informa la posicion en x
	int VerPosY(); ///< informa la posicion en y
	int VerDir(); ///< informa la direccion actual
	bool EsRoja(); ///< dice si es roja o negra
	static void DefinirMaximos(int mx, int my); ///< permite definir el tama�o de la grilla donde caminan las hormigas
};

#endif

