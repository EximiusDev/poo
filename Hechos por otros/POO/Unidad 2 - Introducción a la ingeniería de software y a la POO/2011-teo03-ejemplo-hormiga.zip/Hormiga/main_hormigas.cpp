// Para probar este ejemplo tienen que abrir el archivo de proyecto Hormiga.zpr
// si abren directamente los cpp va a dar errores al compilar
	
#include <iostream>
#include <cstdlib>
#include "zcurlib.h"
#include <ctime>
#include "Hormiga.h"
using namespace std;

/// recibe una hormiga y la dibuja en la posicion que corresponde
void dibuja_hormiga(Hormiga &h) {
	int x=h.VerPosX()+1, y=h.VerPosY()+1, dir=h.VerDir(); // obtiene los datos de la hormiga
	setForeColor(h.EsRoja()?COLOR_RED:COLOR_BLACK); // elige el color para escribir
	switch(dir) { // segun la direccion se dibuja distinto
	case 1: // mira para arriba
		gotoXY(x,y-1); cout<<"v";
		gotoXY(x,y  ); cout<<"8";
		break;
	case 2: // mira para abajo
		gotoXY(x,y  );cout<<"8";
		gotoXY(x,y+1);cout<<"^";
		break;
	case 3: // mira para la derecha
		gotoXY(x,y  ); cout<<"oo<";
		break;
	case 4: // mira para la izquierda
		gotoXY(x-1,y  ); cout<<">oo";
		break;
	}
}

/// espera un ratito para que se vean las hormigas y despues borra todo para empezar a dibujarlas en sus nuevas posiciones
void esperar_y_borrar() {
	hideCursor(); // para que no se ver el cursor de texto despues de la ultima hormiga
	miliSleep(100);  // espera un ratito, porque sino se moverian tan rapido que no se veria nada
	setBackColor(COLOR_WHITE); // pone un color de fondo que no sea negro sino las hormigas negras no se ven
	clrscr(); // borra la pantalla
}

/// main, pide una cantidad de hormigas y arma la colonia, que vive hasta que se aprete cualquier tecla
int main(int argc, char *argv[]) {
	setTitle("Colonia de Hormigas"); // titulo de la ventana
	Hormiga::DefinirMaximos(getScreenWidth()-3,getScreenHeight()-2); // define el tama�o de la pantalla, el constructor de hormiga lo usa para ubicarlas aleatoriamente
	srand(time(0)); // para que los nros al azar no sean siempre los mismos
	int numero_hormigas; // cantidad de hormigas en la colonia
	cout<<"Cuantas hormigas necesita? ";
	cin>>numero_hormigas;
	Hormiga *h=new Hormiga[numero_hormigas]; // crear el arreglo de hormigas
	while(!getKey(false)) { // mientras no se aprete ninguna tecla
		esperar_y_borrar(); // espera un ratito y despues borra la pantalla
		Hormiga::DefinirMaximos(getScreenWidth()-3,getScreenHeight()-2); // por si cambio de tama�o la ventana
		for (int i=0;i<numero_hormigas;i++) { // mueve y dibuja todas las hormigas
			h[i].CaminaDerecho();
			if (rand()%5==0) h[i].CambiaDireccion(); // cada tanto cambian de direcciona
			dibuja_hormiga(h[i]);
		}
	}
	delete []h; // borrar la colonia de hormigas
	return 0;
}
