// 7 mascotas conversando, sin poliformismo

// La clase mascota tiene lo basico, las herencias especializan
// 4 tipos de mascota, donde cada una se comunica diferente

#include <iostream>
#include <cstdlib>
#include <cstring>
using namespace std;

class Mascota {
	char nombre[50];
	char especie[50];
public:
	Mascota(const char *_especie, const char *_nombre) { 
		strcpy(especie,_especie); strcpy(nombre,_nombre);
	}
	const char *VerNombre() { return nombre; }
	const char *VerEspecie() { return especie; }
};

class Perro : public Mascota {
public:
	Perro(const char *_nombre) : Mascota("Perro",_nombre) {}
	void Ladrar() { cout<<"Guau!"; }
};

class Gato : public Mascota {
public:
	Gato(const char *_nombre) : Mascota("Gato",_nombre) {}
	void Maullar() { cout<<"Miau!"; }
};

class Pajaro : public Mascota {
public:
	Pajaro(const char *_nombre) : Mascota("Canario",_nombre) {}
	void Cantar() { cout<<"Pio!"; }
};

class Vaca : public Mascota {
public:
	Vaca(const char *_nombre) : Mascota("Vaca",_nombre) {}
	void Mugir() { cout<<"Muuuu!"; }
};


int main(int argc, char *argv[]) {
	
	Perro p("Mordelon");
	Gato g1("Leon-O");
	Gato g2("Tzygro");
	Gato g3("Chetara");
	Vaca v("Lactica");
	Pajaro p1("Blu");
	Pajaro p2("Perla");
	
	while (true) {
		cin.get();
		int cual=rand()%7;
		if (cual==0) { cout<<p.VerNombre()<<" dice: "; p.Ladrar(); }
		if (cual==1) { cout<<g1.VerNombre()<<" dice: "; g1.Maullar(); }
		if (cual==2) { cout<<g2.VerNombre()<<" dice: "; g2.Maullar(); }
		if (cual==3) { cout<<g3.VerNombre()<<" dice: "; g3.Maullar(); }
		if (cual==4) { cout<<v.VerNombre()<<" dice: "; v.Mugir(); }
		if (cual==5) { cout<<p1.VerNombre()<<" dice: "; p1.Cantar(); }
		if (cual==6) { cout<<p2.VerNombre()<<" dice: "; p2.Cantar(); }
	}
	
	return 0;
}

