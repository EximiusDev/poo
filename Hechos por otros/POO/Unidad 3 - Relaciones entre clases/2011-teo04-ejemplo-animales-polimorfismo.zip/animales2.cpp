// 7 mascotas conversando, con poliformismo

#include <iostream>
#include <cstdlib>
#include <cstring>
using namespace std;

class Mascota {
	char nombre[50];
	char especie[50];
public:
	Mascota(const char *_especie, const char *_nombre) { 
		strcpy(especie,_especie); strcpy(nombre,_nombre);
	}
	const char *VerNombre() { return nombre; }
	const char *VerEspecie() { return especie; }
	virtual void HacerRuido()=0; // LA MAGIA ESTA EN LA PALABRA VIRTUAL
};

class Perro : public Mascota {
public:
	Perro(const char *_nombre) : Mascota("Perro",_nombre) {}
	void HacerRuido() { cout<<"Guau!"; }
};

class Gato : public Mascota {
public:
	Gato(const char *_nombre) : Mascota("Gato",_nombre) {}
	void HacerRuido() { cout<<"Miau!"; }
};

class Pajaro : public Mascota {
public:
	Pajaro(const char *_nombre) : Mascota("Canario",_nombre) {}
	void HacerRuido() { cout<<"Pio!"; }
};

class Vaca : public Mascota {
public:
	Vaca(const char *_nombre) : Mascota("Vaca",_nombre) {}
	void HacerRuido() { cout<<"Muuuu!"; }
};


int main(int argc, char *argv[]) {
	Mascota *m[7]; // solo se puede aprovechar el polimorfismo mediante punteros
	m[0]=new Perro("Mordelon");
	m[1]=new Gato("Leon-O");
	m[2]=new Gato("Tygro");
	m[3]=new Gato("Chetara");
	m[4]=new Vaca("Lactica");
	m[5]=new Pajaro("Blu");
	m[6]=new Pajaro("Perla");
	
	while (true) {
		cin.get();
		int cual=rand()%7;
		cout<<m[cual]->VerNombre()<<" dice: "; m[cual]->HacerRuido();
	}
	
	return 0;
}

