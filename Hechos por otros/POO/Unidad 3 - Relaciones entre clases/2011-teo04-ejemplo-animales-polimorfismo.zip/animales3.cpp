// N mascotas conversando, con poliformismo

#include <iostream>
#include <cstdlib>
#include <cstring>
using namespace std;

class Mascota {
	char nombre[50];
	char especie[50];
public:
	Mascota(const char *_especie, const char *_nombre) { 
		strcpy(especie,_especie); strcpy(nombre,_nombre);
	}
	const char *VerNombre() { return nombre; }
	const char *VerEspecie() { return especie; }
	virtual void HacerRuido()=0;
};

class Perro : public Mascota {
public:
	Perro(const char *_nombre) : Mascota("Perro",_nombre) {}
	void HacerRuido() { cout<<"Guau!"; }
};

class Gato : public Mascota {
public:
	Gato(const char *_nombre) : Mascota("Gato",_nombre) {}
	void HacerRuido() { cout<<"Miau!"; }
};

class Pajaro : public Mascota {
public:
	Pajaro(const char *_nombre) : Mascota("Canario",_nombre) {}
	void HacerRuido() { cout<<"Pio!"; }
};

class Vaca : public Mascota {
public:
	Vaca(const char *_nombre) : Mascota("Vaca",_nombre) {}
	void HacerRuido() { cout<<"Muuuu!"; }
};


int main(int argc, char *argv[]) {
	// en este ejemplo se muestra que la cantidad de mascotas y la especie
	// de cada una varia de una ejecucion a otra, por lo que la desicion
	// de a que metodo llamar cuando son virtuales se toma en la ejecucion
	// y no en compilacion como pasa con los metodos comunes
	int n;
	cout<<"Cuantas mascotas tiene? ";
	cin>>n;
	Mascota **m = new Mascota*[n];
	for(int i=0;i<n;i++) { 
		cout<<"- Mascota 1 -"<<endl;
		cout<<"Nombre: ";
		char nom[50]; 
		cin.ignore();
		cin.getline(nom,50);
		cout<<"Especie (1=perro,2=gato,3=vaca,4=pajaro): ";
		int e;
		cin>>e;
		if (e==1) m[i]=new Perro(nom);
		else if (e==2) m[i]=new Gato(nom);
		else if (e==3) m[i]=new Vaca(nom);
		else if (e==4) m[i]=new Pajaro(nom);
	}
	cout<<endl;
	
	while (true) {
		cin.get();
		int cual=rand()%n;
		cout<<m[cual]->VerNombre()<<" dice: "; m[cual]->HacerRuido();
	}
	
	// faltarian los delete, pero como hay un while true la conversacion no termina jamas
	
	return 0;
}

