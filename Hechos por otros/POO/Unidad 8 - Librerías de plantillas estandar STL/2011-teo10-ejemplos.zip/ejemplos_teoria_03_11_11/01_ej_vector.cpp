#include <iostream>
#include <vector>
#include <cstdlib>
using namespace std;

/* 
 * Ejemplo:
 * Cree dos vectores de 10 elementos e
 * inicialicelos con valores aleatorios.
 * Luego muestrelos.
 */
int main(int argc, char *argv[]) {
	// creamos un vector vacio de enteros
	vector<int> v1;
	
	// creamos un vector de floats con 5 elementos iguales a 0.1
	vector<float> v2(10, 0.1);
	
	// insertamos 10 enteros aleatorios al final del vector v1
	for(int i=0;i<10;i++) { 
		v1.push_back(rand()%100);
	}
	
	// muestra los valores de v1
	cout<<"El vector v1: "<<endl;
	for(int i=0;i<v1.size();i++) { 
		cout<<v1[i]<<endl;
	}
	
	// muestra los valores de v2
	cout<<"El vector v2: "<<endl;
	for(int i=0;i<v2.size();i++) { 
		cout<<v2[i]<<endl;
	}
	
	// asigna valores aleatorios a los elementos de v2
	for(int i=0;i<v2.size();i++) { 
		v2[i]=rand()%100;
	}	
	
	// muestra los valores de v2 pero utilizando iteradores
	cout<<"El vector v2 despues de asignar valores aleatorios: "<<endl;
	vector<float>::iterator p=v2.begin();
	while(p!=v2.end()){
		cout<<*p<<endl;
		p++;
	}
	
	return 0;
}

