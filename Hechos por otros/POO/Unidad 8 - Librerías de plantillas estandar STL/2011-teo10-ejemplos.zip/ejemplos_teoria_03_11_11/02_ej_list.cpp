#include <iostream>
#include <list>
#include <cstdlib>
using namespace std;

/*
 * Ejemplo:
 * Generar una lista e insertarle 10 valores
 * enteros aleatorios entre 0 y 15, ordenarlos
 * y mostrar la lista ordenada. Luego eliminar
 * los valores repetidos y mostrar la lista.
 */
int main(int argc, char *argv[]) {
	// crea una lista vacia
	list<int> l;
	
	// inserta 5 valores al final de la lista
	for(int i=0;i<5;i++) { 
		l.insert(l.end(), rand()%2);
	}
	// y otros 5 valores al principio
	for(int i=0;i<5;i++) { 
		l.insert(l.begin(), i+10);
	}
	
	// muestra la lista
	cout<<"La lista: "<<endl;
	list<int>::iterator p=l.begin();
	while(p!=l.end()){
		cout<<*p<<endl;
		p++;
	}
	
	// ordena la lista
	l.sort();
	
	// muestra la lista ordenada
	cout<<"La lista ordenada: "<<endl;
	p=l.begin();
	while(p!=l.end()){
		cout<<*p<<endl;
		p++;
	}
	
	// invierte el orden de los elemntos de la lista
	l.reverse();
	
	// muestra la lista ordenada e invertida
	cout<<"La lista ordenada e invertida: "<<endl;
	p=l.begin();
	while(p!=l.end()){
		cout<<*p<<endl;
		p++;
	}
	
	// quita los elemntos repetidos
	l.unique();
	
	// muestra la lista ordenada, invertida y sin repetidos
	cout<<"La lista ordenada, invertida y sin repetidos: "<<endl;
	p=l.begin();
	while(p!=l.end()){
		cout<<*p<<endl;
		p++;
	}
	
	return 0;
}

