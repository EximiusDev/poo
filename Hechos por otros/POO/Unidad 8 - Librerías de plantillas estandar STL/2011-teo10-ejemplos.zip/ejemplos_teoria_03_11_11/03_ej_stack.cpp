#include <iostream>
#include <stack>
using namespace std;

/*
 * Ejemplo:
 * Cree una pila para almacenar nombres de
 * personas. Muestre el tama�o de la pila y
 * luego desapile cada elemento y mu�strelo.
 */
int main(int argc, char *argv[]) {
	// crea una pila vacia
	stack<string> s;
	
	// apila 4 nombres
	s.push("pepe");
	s.push("pedro");
	s.push("lalo");
	s.push("lala");
	
	// mientras haya elementos en la pila
	// los muestra y luego los desapila
	cout<<"La pila: "<<endl;
	while(!s.empty()){
		cout<<s.top()<<endl;
		s.pop();
	}
	
	return 0;
}

