#include <iostream>
#include <queue>
using namespace std;

/*
 * Ejemplo:
 * Cree una cola para almacenar datos de la
 * estructura mostrada debajo. Encole los
 * elementos y muestrelos a medida que son
 * eliminados.
 * 
 * struct Paciente{
 *     string nombre;
 *     int numero;
 * };
 */


struct Paciente{
	string nombre;
	int numero;
	Paciente(string nom, int num):nombre(nom), numero(num){};
};


int main(int argc, char *argv[]) {
	// crea una cola vacia
	queue<Paciente> c;
	
	// encola pacientes en la estructura
	c.push(Paciente("pepe", 1));
	c.push(Paciente("pablo", 3));
	c.push(Paciente("lalo", 5));
	c.push(Paciente("landa", 10));
	
	// mientras queden pacientes en la cola
	// los muestra y los va quitando
	cout<<"La cola: "<<endl;
	while(!c.empty()){
		Paciente p("",0);
		p=c.front();
		cout<<p.nombre<<" "<<p.numero<<endl;
		c.pop();
	}
	
	return 0;
}

