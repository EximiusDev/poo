#include <iostream>
#include <map>
using namespace std;

/*
 * Ejemplo:
 * Utilice un mapeo para manejar el conjunto
 * de calificaciones de un grupo de alumnos.
 * Pida al usuario que ingrese el nombre de
 * un alumno e informe su nota o un mensaje
 * alusivo en caso de no encontrar al alumno.
 */	
int main(int argc, char *argv[]) {
	// crea un mapeo vacio de claves string a valores int
	map<string, int> m;
	
	// inserta algunos alumnos con sus notas
	pair<string, int> elPar;
	elPar.first="pepe";
	elPar.second=9;
	m.insert(elPar);
	m.insert(pair<string, int>("pablo", 10));
	m.insert(pair<string, int>("lalo", 2));
	// esta insercion no se realiza porque ya existe un par con el
	// mismo valor de esa clave
	m.insert(pair<string, int>("pablo", 1));
	
	// pide al usuario que ingrese el nombre de un alumno
	string nombreAlumno;
	cout<<"Ingrese el nombre de un alumno: ";
	cin>>nombreAlumno;
	
	// realiza la busqueda del alumno
	map<string, int>::iterator p=m.find(nombreAlumno);
	
	// si el iterador es distinto de m.end(), la busquda fue exitosa
	if(p!=m.end()){
		cout<<"La nota de "<<nombreAlumno<<" es: "<<p->second<<endl;
	}else{
		cout<<"ERROR: no se encontro la nota de "<<nombreAlumno<<endl;
	}
	
	return 0;
}

