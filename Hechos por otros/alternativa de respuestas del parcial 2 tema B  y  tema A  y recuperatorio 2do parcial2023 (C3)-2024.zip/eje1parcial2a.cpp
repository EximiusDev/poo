/*
a) Dise�e una funci�n gen�rica promedio(...) que reciba una lista (list) de datos
   de cualquier tipo y calcule el promedio de los elementos.
b) Escriba un programa en C++ que sea un cliente de la funci�n promedio(...). El
   programa debe invocar la funci�n tres veces para las siguientes listas:
i) Una lista de n�meros flotantes ingresados por el usuario desde el teclado.
ii) Una lista de n�meros enteros generados aleatoriamente en el rango de 1 a 100.
iii) Una lista de n�meros complejos (struct Complejo { float p_real, p_imag; }) 
  que deben leerse desde un archivo binario "complejos.dat". 
  Nota: implemente todas las funciones auxiliares que considere necesarias para 
        que el programa funcione.
*/

#include <iostream>
#include <list>
#include <cstdlib>
#include <ctime>
#include <fstream>
using namespace std;

//las sobrecargas las hice como miembros del struct, pero se pueden hacer 
//como funciones independientes...
//lo mismo los constructores para evitar cargar los miembros luego...

//para el punto b-iii
struct Complejo { 
	float p_real, p_imag;
	Complejo(){p_real=0; p_imag=0;}
	Complejo(float x, float y){p_real=x; p_imag=y;}
	Complejo operator+(Complejo x){
	  Complejo suma(p_real+x.p_real,  p_imag+x.p_imag); return suma;
	}
	Complejo operator / (int x){
		Complejo divi(p_real / (1.0 * x), p_imag / (1.0 * x)); return divi;
	}
	
};

//a)
template<typename T>
T promedio(list<T> l){
  auto prim=l.begin();  
  T s = *prim;
  prim++;
  for(auto it=prim;it!=l.end();it++)
	  s=s + *it;
  return s / l.size();
}
  
 //-----------------no es necesario------------------- 
  void generabinario(){  //no lo pide pero es para crear al archivo binario
     ofstream f("complejos.dat",ios::binary);
	 srand(time(0));
	 for(int i=0;i<5;i++) { 
		 Complejo aux(rand()%10, rand()%10);
		 cout<<aux.p_real<<"+"<<aux.p_imag<<"i\n";
		 f.write((char*)&aux,sizeof(aux));
	 }
	 cout<<"archivo de complejos generado\n\n";
	 f.close();
  }
 //----------------------------------------------------- 
  
int main(int argc, char *argv[]) {
// b-i)
    list<float>lf;
	for(int i=0;i<5;i++) { 
		float nf;
		cout<<"ingrese valor: "; cin>> nf;
		lf.push_back(nf);
	}
	cout<<"\npromedio de flotantes: "<< promedio<float>(lf)<<endl<<endl;
	
// b-ii)
	list<int>li;
	srand(time(0));
	for(int i=0;i<5;i++) { 
		int ni=rand()%100+1;
		li.push_back(ni);
		cout<<ni<<"  ";
	}                     //tener en cuenta que la division de enteros da un entero
	cout<<"\n\npromedio de enteros: "<< promedio<int>(li)<<endl<<endl;
	
// b-iii)
	//generabinario();  //no lo pide pero es para crear al archivo binario
    ifstream f("complejos.dat", ios::binary|ios::ate);
	int cant=f.tellg()/sizeof(Complejo);
	f.seekg(0);
	list<Complejo> lc;
	for(int i=0;i<cant;i++) { 
		Complejo c;
		f.read((char*)&c,sizeof(c));
		lc.push_back(c);
		cout<<c.p_real<<"+"<<c.p_imag<<"i\n";
	}
	f.close();
	Complejo pr=promedio<Complejo>(lc);
	cout<<"\n\npromedio de complejos: "<< pr.p_real<<"+"<<pr.p_imag<<"i\n";
	
	return 0;
}

