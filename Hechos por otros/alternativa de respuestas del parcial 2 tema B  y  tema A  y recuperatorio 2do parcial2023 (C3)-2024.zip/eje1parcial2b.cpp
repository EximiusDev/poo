/* Ej 1 (30 ptos )  Se tiene un archivo de textos �listado.txt� con un nombre y
 apellido en cada l�nea de los alumnos inscriptos a m�tem�tica. En una revisi�n
 se determin� que el total de datos superaban los 300 (cantidad que deb�an ser)
 debido a que estos datos fueron pasados por distintas personas y se hab�an pasado
 varias veces los datos de un mismo alumno. Se desea procesar el listado de tal 
forma que no haya datos repetidos. 
a) Escriba un programa que cargue los datos en  un vector de string y elimine 
   los repetidos. 
b) Adem�s se les quiere proporcionar email institucional a cada uno, el cual se 
   debe generar a partir de la primer letra del nombre, el apellido completo y el
   dominio �@fich.unl.edu.ar� (suponer que en cada string inicial hay un solo 
   nombre y un solo apellido separados por espacio). 
c) Por �ltimo, debe generar 5 archivos texto llamados �comision1.txt�, 
   �comision2.txt�.... �comision5.txt�, con los datos de 60 alumnos cada uno de la
   siguiente manera: apellido, nombre, correo (uno por linea, las tres partes 
   separadas por coma). Por ejemplo si el alumno se llama �Juan Perez�, en el archivo
   se deber� guardar �Perez, Juan, jperez@fich.unl.edu.ar�.
*/
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;

struct alumno{
	string nombre, apellido, email;
};

int main(int argc, char *argv[]) {
//a)
    ifstream archi("listado.txt");
	vector<string> v;
	string alum;
	while(getline(archi,alum)){
		v.push_back(alum);
	}
	archi.close();
	cout<<"Se leyeron: "<<v.size()<<endl;
	sort(v.begin(),v.end());
	auto it=unique(v.begin(),v.end());
	v.erase(it,v.end());
	cout<<"Despues de sacar los repetidos quedaron: "<< v.size()<<endl;
//b)
	vector<alumno> listadoAlumnos;
	for(size_t i=0;i<v.size();i++) { 
	  alumno a;
	  a.nombre=v[i].substr(0,v[i].find(" "));      //copia del comienzo hasta el espacio
	  a.apellido=v[i].substr(v[i].find(" ")+1);    //copia del espacio hasta el final
	  a.email=a.nombre[0]+a.apellido+"@fich.unl.edu.ar";
	  listadoAlumnos.push_back(a);
	}
//c)
	int k=0;
	for(int i=1;i<6;i++) {
		ofstream fs("comision"+to_string(i)+".txt",ios::trunc);
		for(int j=0;j<60;j++) { 
			fs<<listadoAlumnos[k].apellido<<", "<<listadoAlumnos[k].nombre<<", "<<listadoAlumnos[k].email<<endl;
			k++;
		}
		fs.close();
		cout<<"archivo "<<"comision"<<i<<".txt" <<" generado\n";
	}	
	return 0;
}

