/*Ejercicio 2 (30 ptos) 
Se dispone de un archivo de textos llamado �datos.txt� generado por un equipo que
mide una vez al d�a la altura del r�o. Para simplificar, suponer que todos los 
meses tienen 30 d�as; entonces el archivo tendr� 30*12=360 datos.
a) Escriba un programa C++ que lea el archivo  y organice todos los datos en un 
   �nico contenedor STL.
b) Obtenga el mayor valor de cada mes, y genere con estos 12 valores un nuevo 
   vector donde cada posici�n contenga una terna de datos: nro de mes, valor m�ximo
   de ese mes, y cu�ntas veces se repiti� ese valor m�ximo en el mes.
c) Ordene el nuevo vector de mayor a menor (seg�n el valor m�ximo de cada terna)
   y luego guarde estas 12 ternas en un archivo binario �m�ximos.dat�.
*/
#include <iostream>
#include <vector>
#include <fstream>
#include <algorithm>
#include <iomanip>
using namespace std;
struct terna{
	int mes, maximo, repite;
};
//sobrecargo el < para poder usar el sort
bool operator<(terna x, terna y){
	return x.maximo<y.maximo;
}

//no va, solo para verificar los valores leidos del archivo
void ver(vector<int> &x){
	cout<<"valores leidos del archivo:\n";
		for(int i=0;i<12;i++) { 
		cout<<setw(3)<<i+1<<": ";
		for(int j=0;j<30;j++) { 
			cout<<setw(4)<<x[i*12+j];
		}
		cout<<endl;
	}
}
//------------------------------------------------------------	


int main(int argc, char *argv[]) {
//a)
	ifstream t("datos.txt");
	vector <int> v;
	int m;
	while(t>>m){
		v.push_back(m);
	}
	t.close();
//b)
	vector<terna> may(12);
	int mes=0;
	ver(v);
	cout<<endl;
	for(int i=0;i<12;i++) {
		may[i].mes=mes+1;
		may[i].maximo=*max_element(v.begin()+30*mes,v.begin()+30*mes+30);
		may[i].repite=count(v.begin()+30*mes,v.begin()+30*mes+30,may[i].maximo);
		//cout<<distance(v.begin(),v.begin()+30*mes)<<","<<distance(v.begin(),v.begin()+30*mes+30)<<endl;
		mes++;
	}

//c)
	
	cout<<"maximos\n";
	cout<<"valor mes  repite\n";
	
	sort(may.begin(),may.end());       
	reverse(may.begin(),may.end());
	ofstream f("maximos.dat",ios::binary|ios::trunc);
	for(int i=0;i<12;i++) { 
		f.write((char*)&may[i],sizeof(may[i]));
		cout<<may[i].maximo<<"     "<<may[i].mes<<"     "<<may[i].repite<<endl;
	}	
	f.close();
	return 0;
}

