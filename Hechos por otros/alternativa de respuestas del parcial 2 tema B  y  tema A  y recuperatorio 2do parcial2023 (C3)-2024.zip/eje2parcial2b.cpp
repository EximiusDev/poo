/*
Ej 2 (30 ptos) Un estudio de juegos indie te contrata como programador. Tu primer trabajo es programar una clase llamada TDP 
(abreviatura de �Tabla De Puntajes�) que le ser� de utilidad al estudio para sus proyectos actuales y pr�ximos. El estudio te
 solicita que la clase maneje la TDP de un juego en particular, la cual se guardar� en la base de datos del estudio como un 
archivo binario con el nombre �puntuaciones_juego.dat� donde �juego� se reemplaza con el nombre del juego. Pero hay un problema: 
los distintos juegos de la empresa tienen distintos criterios de puntaje. Mientras que el juego SPACE SHOOTERS guarda sus puntajes 
como una lista de enteros, el juego FROG RACING guarda sus puntajes como floats, y es posible que los pr�ximos lanzamientos de la
 empresa utilicen distintos criterios. Se sabe que no importa el criterio que usen, siempre se pueden comparar los puntajes para
 ver qu� jugador obtuvo el mejor puntaje, y que los mismos se identifican a trav�s de un atributo nom (que no es m�s que un
 arreglo de 5 chars, e identifica a un �nico jugador, por lo que dos puntajes se consideran iguales si tienen el mismo nom).
 Entonces, para demostrarle a la empresa que hicieron bien en contratarte:
-  Implemente la clase gen�rica TDP que resuelva este problema para la empresa. La clase recibe en su constructor el nombre del
   juego, y debe cargar en memoria los datos de la tabla de puntuaciones del juego.
-  Tambi�n debe ser posible agregar puntajes. Si el jugador a agregar ya ten�a un puntaje, debe actualizarlo (se guarda el �ltimo
   puntaje, no el mejor).
-  Y debe poder mostrar una lista ordenada de los noms de menor a mayor.
-  Finalmente, la clase debe poseer una forma de actualizar el archivo binario de la base de datos (y debe actualizarse 
   autom�ticamente cuando la clase se destruye). 
*/
#include <iostream>
#include <cstring>
#include <list>
#include <vector>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <algorithm>
using namespace std;

void generaArchi(); //no es necesario, lo hice para generar los archivos y poder probar (el codigo esta al final)
	

//supongo que cada juego tiene una estructura diferente de almacenar la informacion.....
struct fichaInt{
	char nom[5];
	int punt;
};

struct fichaFloat{
	char nom[5];
	float punt;
};

//sobrecarga para poder usar el find teniendo en cuenta solo el nombre
template <class T>    
bool operator==(T x,T y){
	//return strcmp(x.nom, y.nom)==0;             //con operaciones de comapracion de cstring  o 
	return (string)x.nom == (string)y.nom;        //casteando el cstring para usarlo como string
}

//sobrecarga para poder usar el sort de acherdo al nombre
template <class T>
bool operator<(T x,T y){
	//return strcmp(x.nom, y.nom)<0;             //con operaciones de comapracion de cstring  o 
	return (string)x.nom  < (string)y.nom;        //casteando el cstring para usarlo como string
}
				
template <class T>
class TDP {
	vector<T> v;
	string narchi;
public:
	TDP(string x){
		narchi="puntuaciones_"+ x + ".dat"; 
	    fstream f(narchi,ios::binary|ios::in|ios::out|ios::ate);
		int cant=f.tellg()/sizeof(T);
		T aux;
		f.seekg(0);
		for(int i=0;i<cant;i++) {
			f.read((char*)&aux, sizeof(aux));
			v.push_back(aux);
		}
		f.close();
	}
	void agregar(T x){
		auto it=find(v.begin(),v.end(),x);  
		if(it==v.end())
			v.push_back(x);
		else
			(*it).punt=x.punt;
	}
	void ver(){
		sort(v.begin(),v.end());
		for(T x:v) {
			cout<< x.nom <<"  -  "<< x.punt<<endl;
		}
	}
	~TDP(){
		fstream f(narchi,ios::binary|ios::in|ios::out|ios::trunc);
		for(T x:v){
			f.write((char*)&x, sizeof(x));
		}
		f.close();
	}
};


int main() {
	//generaArchi();  //comentar despues de una ejecucion para que no sobreescriba los archivos nuevamente
	TDP <fichaInt> fi("SPACESHOOTERS");
	TDP <fichaFloat> ff("FROGRACING");
	fichaInt w;
	fi.ver();
	cout<<endl;
	ff.ver();
	cout<<"\ningrese nombre y puntaje de una ficha entero: ";
	cin>>w.nom;
	cin>>w.punt;
	fi.agregar(w);
	fi.ver();
	
	return 0;
}


//no es necesario, lo hice para generar los archivos y poder probar
//genera los archivos con nombres y puntos al azar
void generaArchi(){   
	fichaInt aux;
	srand(time(0));
	vector<string> letras={"A","B","E","R","M","R","T","B","C","J","W","O"};  //12
	fstream f1("puntuaciones_SPACESHOOTERS.dat",ios::binary|ios::in|ios::out|ios::trunc);
	for(int i=0;i<10;i++) { 
		string no=letras[rand()%12]+letras[rand()%12]+letras[rand()%12]+letras[rand()%12];
		strcpy(aux.nom, no.c_str());
		aux.punt=rand()%100;
		f1.write((char*)&aux,sizeof(aux));
	}
	f1.close();
	fichaFloat aux2;
	fstream f2("puntuaciones_FROGRACING.dat",ios::binary|ios::in|ios::out|ios::trunc);
	for(int i=0;i<10;i++) { 
		string no=letras[rand()%12]+letras[rand()%12]+letras[rand()%12]+letras[rand()%12];
		strcpy(aux2.nom, no.c_str());
		aux2.punt=rand()%100/3.2;
		f2.write((char*)&aux2,sizeof(aux2));
	}
	f2.close();
}
	
