/*
Ejercicio 2 (30pts) a) Dise�e una funci�n gen�rica llamada ordenarExtremos, que 
reciba una lista (std::list) de datos de cualquier tipo, determine los valores 
m�nimo y m�ximo, y reordene la lista moviendo el m�nimo al comienzo y el m�ximo 
al final (el resto de la lista debe quedar como estaba). Si el m�nimo o el m�ximo
aparecen m�s de una vez, se debe mover todas las ocurrencias. Por ejemplo, si recibe
una lista inicial de enteros conteniendo { 3, 1, 7, 5, 1, 6, 4 }, la lista modificada
deber� quedar { 1, 1, 3, 5, 6, 4, 7 }.
b) Escriba un programa cliente que pruebe la funci�n con dos listas: una de strings, 
y otra de structs que contienen cada uno una fecha y la temperatura m�xima de esa 
fecha (struct Temp { int aaaammdd; float grados; }). En la segunda lista, se deber�
considerar m�nimo/m�ximo elemento al de menor/mayor temperatura sin importar su fecha.
En ambos casos el usuario ingresar� los valores y el programa deber� informar las dos
listas modificadas.
Nota: Implemente todas las funciones auxiliares que considere necesarias para que
el programa funcione correctamente.
*/

#include <iostream>
#include <algorithm>
#include <list>
using namespace std;


struct Temp { 
	int aaaammdd; 
	float grados; 
};

bool operator==(Temp x, Temp y){
	return x.grados==y.grados;
}
bool operator< (Temp x, Temp y){
	return x.grados<y.grados;
}
ostream & operator<<(ostream &sal, Temp &x){    //puedo no hacer esta sobrearga e informar cada miembro en el main
	sal<<x.aaaammdd<<": "<<x.grados;
	return sal;
}

template<typename T>
void ordenarExtremos(list<T> &x){
	T ma= *max_element(x.begin(),x.end());		//obtengo el valor mayor apuntado por el iterador
	T mi= *min_element(x.begin(),x.end());		//obtengo el valor menor apuntado por el iterador
	int cma=count(x.begin(),x.end(),ma);		//cuento los mayores
	int cmi=count(x.begin(),x.end(),mi);		//cuento los menores
	x.remove(mi);								//borro todos los menores
	x.remove(ma);								//borro todos los mayores
	for(int i=0;i<cmi;i++)
		x.push_front(mi); 	//agrego la cantidad de menores borrados al inicio
	for(int i=0;i<cma;i++)
		x.push_back(ma);	//agrego la cantidad de mayores borrados al final
	
		
	/*  //alternativa a los 2 remove y a los 2 for siguientes
	for(int i=0;i<cma;i++) {           
		x.erase(find(x.begin(),prev(x.end(),i),ma));
		x.push_back(ma);
	}
	for(int i=0;i<cmi;i++) { 
		x.erase(find(next(x.begin(),i),x.end(),mi));
		x.push_front(mi);
	}
	*/
}
	
	
int main(int argc, char *argv[]) {
	list<int>li={ 3, 1, 7, 5, 1, 6, 4, 1, 1, 7, 5 };
	for(int z:li)
		cout<<" "<<z;
	cout<<endl;
	
	ordenarExtremos<int>(li);
	
	for(int z:li)
		cout<<" "<<z;
	cout<<endl;
	
	
	list<Temp>lt={{20230912,31},{20231112,34},{20231012,21},{20231114,37},{20231002,34},
	{20231115,24},{20230718,25},{20231114,30},{20230902,34},{20230719,37},{20231001,34},
	{20231123,23},{20230519,21},{20231112,34},{20230412,30},{20230812,34}};
	
	for(Temp z:lt)
		cout<<z<<endl;
	cout<<endl;
	
	ordenarExtremos<Temp>(lt);
	
	for(Temp z:lt)
		cout<<z<<endl;
	cout<<endl;
	
	return 0;
}

