/*
Escriba una clase Cola para representar una cola de trabajos pendientes. La clase
debe ser gen�rica: el tipo de struct utilizado para representar un trabajo debe 
ser el argumento T de la plantilla. Asuma que el struct T con el que se especialice
la plantilla siempre tendr� un campo entero id. Por ejemplo, el programa cliente
podr�a definir:
struct TrabajoImpresion { int id; bool color; int cant_pags; string archivo; };
Cola<TrabajoImpresion> cola_impresion; // gestiona las impresiones pendiente
La clase Cola debe guardar internamente una secuencia de trabajos y tener m�todos
para:
- Agregar un trabajo: el que se agrega siempre va como �ltimo trabajo, y se le asigna
  un nuevo id. El primer trabajo tendr� el id 1, el 2do el 2, el 3ro el 3, y as� 
  sucesivamente. Ayuda: guarde el �ltimo id utilizado como atributo en la clase 
  Cola para saber cu�l sigue al agregar.
- Obtener el pr�ximo trabajo a realizar: el m�todo debe quitar de la lista al primer
  trabajo y retornarlo.
- Cancelar un trabajo seg�n su id: debe buscar el trabajo por su id y eliminarlo.
  Retornar true si lo encontr�, false en caso contrario.
- Obtener la cantidad de trabajos.
- Obtener todos los datos de un trabajo seg�n su posici�n.
		*/
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
struct TrabajoImpresion {
	int id;
	bool color;
	int cant_pags;
	string archivo; 
};

template<typename T>
bool operator==(T x,T y){
	return x.id==y.id;
}

template<typename T>
class Cola{
	vector<T> trabajos;
	int ultimoId;
public:
	Cola() : ultimoId(1){}
	T siguienteTrabajo(){                     
		T x = *trabajos.begin();             // obtengo el primertrabajo
		trabajos.erase(trabajos.begin());    // elimino el primer trabajo
		return x;
	}
	void agregarTrabajo(T x){
		x.id=ultimoId;
		trabajos.push_back(x);
		ultimoId++;
	}
	bool cancelarTrabajo(int tid){
		T aux; aux.id=tid;                                    // creo un struct auxiliar con el id a bbuscar para poder usar el find
		auto it= find(trabajos.begin(),trabajos.end(), aux);   //para usar el find con struct debo sobrecarcar el == con el campo a comparar
		if ( it != trabajos.end() ){                                                       //podria haber hecho una busqueda secuencial
		    trabajos.erase(it);
			return true;
		}
		return false;
	}
	int cantidadTrabajos(){
		return trabajos.size();
	}
	T obtenerTrabajo(int x){
		return trabajos[x];
	}
};

// ****************************************************************
//  el main no se pedia en el parcial, lo hice para probar la clase
// ****************************************************************

int main(int argc, char *argv[]) {
	Cola<TrabajoImpresion> cola_impresion;
	cola_impresion.agregarTrabajo({0,true,10,"plano.jpg"});
	cola_impresion.agregarTrabajo({0,true,40,"afiche.pdf"});
	cola_impresion.agregarTrabajo({0,false,130,"parcialPOO.txt"});
	cola_impresion.agregarTrabajo({0,false,200,"algebra.txt"});
	cola_impresion.agregarTrabajo({0,true,5,"tarjetas.pdf"});
	cola_impresion.agregarTrabajo({0,false,10,"apunte.txt"});
	cola_impresion.agregarTrabajo({0,true,45,"fotos.jpg"});
	cola_impresion.agregarTrabajo({0,false,18,"tpcoe.pdf"});
	
	TrabajoImpresion taux;
	
	cout <<"\nlistado:\n";
	for(int i=0;i<cola_impresion.cantidadTrabajos();i++) { 
		taux=cola_impresion.obtenerTrabajo(i);
		cout<< "id: "<< taux.id << "    color: "<< taux.color <<"   paginas: "<<
			taux.cant_pags << "  archivo: "<<taux.archivo<<endl;; 
	}
	
	cout <<"Siguiente trabajo:\n";
	taux= cola_impresion.siguienteTrabajo();
	cout<< "id: "<< taux.id << "    color: "<< taux.color <<"   paginas: "<<
		taux.cant_pags << "  archivo: "<<taux.archivo<<endl;; 
	
	cout <<"\nlistado despues de haber atendido el trabajo siguiente de la cola:\n";
	for(int i=0;i<cola_impresion.cantidadTrabajos();i++) { 
		taux=cola_impresion.obtenerTrabajo(i);
		cout<< "id: "<< taux.id << "    color: "<< taux.color <<"   paginas: "<<
			taux.cant_pags << "  archivo: "<<taux.archivo<<endl;; 
	}
		
	cout <<"\ningrese un id de un trabajo a cancelar: ";
	int idc;
	cin>> idc;
	if(cola_impresion.cancelarTrabajo(idc))
		cout<<"\ntrabajo cancelado con exito!!!\n";
	else
		cout<<"\nno se encuentra el id del trabajo\n";
	
	cout <<"\nlistado despues de haber intentado cancelar el trabajo:\n";
	for(int i=0;i<cola_impresion.cantidadTrabajos();i++) { 
		taux=cola_impresion.obtenerTrabajo(i);
		cout<< "id: "<< taux.id << "    color: "<< taux.color <<"   paginas: "<<
			taux.cant_pags << "  archivo: "<<taux.archivo<<endl;; 
	}
	
	return 0;
}

