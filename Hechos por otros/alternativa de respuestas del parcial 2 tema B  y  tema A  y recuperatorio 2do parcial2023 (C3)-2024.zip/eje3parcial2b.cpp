/*
Ej 3 (30 ptos ) Escribir una clase gen�rica  llamada OperaLista que posea como 
atributo una lista din�mica (list). 
a) La clase debe poseer m�todos para construirla lista a partir de un vector que
 se pasa como parametro u m�todos para 
b) Agregar un elemento  
c) Obtener la cantidad de elementos 
d) Ordenar la lista en forma decreciente y retornar cuantas veces se repite el 
mayor elemento. 
e) Eliminar un elemento de la lista cuya posici�n se pasa como par�metro 
f) un m�todo para mostrar por pantalla los elementos de la lista.
Defina un programa cliente con 2 instancias de OperaLista empleando enteros y strings.
Los datos deben leerse de los  archivos de texto listaenteros.txt y listastring.txt
respectivamente. El programa debe mostrar ambas listas, y cuantas veces se repite
el mayor de cada una.
*/
#include <iostream>
#include <algorithm>
#include <vector>
#include <list>
#include <fstream>
using namespace std;

template<typename T>
class OperaLista{
	list<T>l;
public:
	OperaLista(vector<T> v){				//a)
		for(size_t i=0;i<v.size();i++) { 
			l.push_back(v[i]);
		}
	}
	void agrega(T x){ 						//b)
		l.push_back(x);
	}
	int cantidad(){							//c)
		return l.size();		
	}
	int ordenaYCuenta(){					//d)
		l.sort();
		l.reverse();
		return count(l.begin(),l.end(),*l.begin());    //como esta ordenada de mayor a menor el mayor esta en primr lugar
	}
	void eliminar(int pos){					//e)
		l.erase(next(l.begin(),pos));
	}	
	void ver(){								//f)
		for(T x:l)
			cout<<x<<"  ";
	}
};

int main(int argc, char *argv[]) {   //en el examen no eran necesario tantos cout... 
	vector <int> ve;              
	ifstream fe("listaenteros.txt");
	int d;
	while(fe>>d) 
		ve.push_back(d);
	fe.close();
	OperaLista<int> opi(ve);
	cout<<"lista original:    ";
	opi.ver();cout<<endl;
	cout<<"el mayor se repite: "<<opi.ordenaYCuenta()<<endl;
	cout<<"lista ordenada:    ";
	opi.ver(); cout<<endl;
	opi.eliminar(6);
	cout<<"lista c/eliminado: ";
	opi.ver(); cout<<endl;
	cout<<endl;cout<<endl;
	vector <string> vs;
	ifstream fs("listastring.txt");
	string s;
	while(getline(fs,s)) 
		vs.push_back(s);
	fs.close();
	OperaLista<string> ops(vs);
	cout<<"lista original:    ";
	ops.ver();cout<<endl;
	cout<<"el mayor se repite: "<<ops.ordenaYCuenta()<<endl;
	cout<<"lista ordenada:    ";
	ops.ver(); cout<<endl;
	ops.eliminar(8);
	cout<<"lista c/eliminado: ";
	ops.ver(); cout<<endl;
	
	
	return 0;
}

