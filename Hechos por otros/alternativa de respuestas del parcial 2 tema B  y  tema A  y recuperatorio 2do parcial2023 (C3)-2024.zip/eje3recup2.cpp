/*
Ejercicio 3 (25pts) Un docente de Computaci�n Gr�fica genera las pr�cticas de 
la siguiente forma: Escribe un programa que sirve para demostrar alguna t�cnica 
de la materia, luego borra la parte m�s importante, y le da ese c�digo incompleto
 a los alumnos para que lo vuelvan a completar. Para automatizar la tarea, en el
 primer paso el docente a�ade una l�nea de comentario que dice exactamente 
"// comienzo soluci�n" antes de cada secci�n del c�digo que hay que remover, y 
otra "// fin soluci�n" luego. Necesita que usted escriba una funci�n que dado el
nombre de un archivo de c�digo fuente, lo modifique eliminando todas las secciones
que est�n delimitadas por estos dos comentarios y poniendo en su lugar (en lugar
de cada secci�n eliminada) una �nica l�nea que diga �// COMPLETAR�. 
Tenga en cuenta que un archivo puede tener una secci�n, varias, o puede no tener
ninguna. La funci�n debe retornar la cantidad de l�neas de c�digo eliminadas 
(sin contar las de los comentarios delimitadores). 
Nota: un archivo de c�digo fuente es un archivo de texto.
*/
#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
using namespace std;

int arregla(string narchi){
	ifstream f(narchi);
	vector<string> v;
	string s;
	while(getline(f,s)){
		v.push_back(s);
	}
	f.close();
	int cant=0;
	for(int i=0;i<v.size();i++) { 
		auto ini= find(v.begin(),v.end(),"// comienzo solucion");
		auto fin= find(v.begin(),v.end(),"// fin solucion");
		if(ini != v.end()){
		    cant+=fin-ini-1;
			*ini="// COMPLETAR";
			v.erase(ini+1, fin+1);
		}
	}
	ofstream r("p"+narchi);  //agrego la 'p' para no sobreescribir el archivo y hacer pruebas
	for(string x:v)
		r<<x<<endl;
	r.close();
	return cant;
}

int main(int argc, char *argv[]) {
	cout<<"lineas eliminadas: "<<arregla("p.txt");
	return 0;
}

