#include "Life.h"

Life::Life() {
	
}

