#ifndef LIFE_H
#define LIFE_H

class Life {
public:
	Life();
private:
};

#endif

