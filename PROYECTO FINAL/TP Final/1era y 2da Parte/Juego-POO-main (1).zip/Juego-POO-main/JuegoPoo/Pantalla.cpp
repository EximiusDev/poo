#include "Pantalla.h"
#include <SFML/Graphics.hpp>
#include <SFML/Graphics/RenderWindow.hpp>
#include <SFML/Window/VideoMode.hpp>
#include <iostream>
#include "TexturePer.h"
using namespace std;
Pantalla::Pantalla():w(VideoMode(1920,1080),"Juego De P.O.O") {};///Al usar el constructo de la clase genero la pantalla con un tamanio q no se cambiara 

void Pantalla::Run(string Nom){ ///Con este metodo empiezo a correr el juego
	Event evt; ///Clase Event
	TexturePer Per(Nom);///Genero el personaje
	Color color(255,255,255,255);///Color de fondo 
	int x=100;int y=100;
	Per.Pos(x,y);
	TexturePer Fondo1("1.png");
	TexturePer Fondo2("2.png");
	TexturePer Fondo3("3.png");
	TexturePer Fondo4("4.png");
	TexturePer Fondo5("5.png");
	Fondo1.Tam(3.5,3.5);
	Fondo2.Tam(3.5,3.5);
	Fondo3.Tam(3.5,3.5);
	Fondo4.Tam(3.5,3.5);
	Fondo5.Tam(3.5,3.5);
	while(w.isOpen()) {
		while(w.pollEvent(evt)) {
			if(evt.type == Event::Closed)
				w.close();}
		
		
		w.clear(color);
		w.draw(Fondo1.Vs());
		
		w.draw(Fondo2.Vs());
		w.draw(Fondo3.Vs());
		w.draw(Fondo4.Vs());
		w.draw(Fondo5.Vs());
		w.draw(Per.Vs());
		w.display();
		
		
		if(Keyboard::isKeyPressed(Keyboard::Key::Down)){
			Per.Pos(x,y);
			y++;}
		if(Keyboard::isKeyPressed(Keyboard::Key::Left)){
			Per.Pos(x,y);
			Fondo1.Pos(-x*2,0 );
			Fondo2.Pos(-x*3,0 );
			Fondo3.Pos(-x*4,0 );
			Fondo4.Pos(-x*5,0);
			Fondo5.Pos(-x*6,0 );x--;}
		if(Keyboard::isKeyPressed(Keyboard::Key::Right)){
			Per.Pos(x,y);
			Fondo1.Pos(-x*2,0 );
			Fondo2.Pos(-x*3,0 );
			Fondo3.Pos(-x*4,0 );
			Fondo4.Pos(-x*5,0);
			Fondo5.Pos(-x*6,0 );x++;}
		if(Keyboard::isKeyPressed(Keyboard::Key::Up)){
			Per.Pos(x,y);y--;}
}}


	/*while(w.isOpen()) {
	while(w.pollEvent(evt)) {
		if(evt.type == Event::Closed)
			w.close();}
	
	
	
	
	w.display();
}}*/
