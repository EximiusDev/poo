#ifndef Pantalla_h
#define Pantalla_h
#include <SFML/Graphics.hpp>
#include <SFML/Graphics/RenderWindow.hpp>
#include <string>
#include "TexturePer.h"
using namespace std;
using namespace sf;
class Pantalla {
private:
	RenderWindow w;
public:
	Pantalla();
	void Run(string Nom);
	
};

#endif

