#include "TexturePer.h"
#include <SFML/Graphics.hpp>
#include <string>
#include <SFML/Graphics/Texture.hpp>
TexturePer::TexturePer(string Nom) {
	t.loadFromFile(Nom);
	s.setTexture(t);
}
void TexturePer::Pos(float x1,float y1){
	s.setPosition(x1,y1);
	this ->x =x1;
	this ->y =y1;
}
void TexturePer::Tam(float tam1,float tam2){
	s.setScale(tam1,tam2);
}
Sprite TexturePer::Vs(){return s;}
float TexturePer::verx(){return x;}
float TexturePer::very(){return y;}
