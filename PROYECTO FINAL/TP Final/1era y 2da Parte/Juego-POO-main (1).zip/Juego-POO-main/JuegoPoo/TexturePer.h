#ifndef TexturePer_h
#define TexturePer_h
#include <SFML/Graphics.hpp>
#include <string>
#include <SFML/Graphics/Texture.hpp>

using namespace std;
using namespace sf;

class TexturePer {
private:
	Texture t;
	Sprite s;
	float x,y;
public:
	TexturePer(string Nom);
	void Pos(float x1,float y1);
	float verx();
	float very();
	Sprite Vs();
	void Tam(float tam1,float tam2);
};

#endif

