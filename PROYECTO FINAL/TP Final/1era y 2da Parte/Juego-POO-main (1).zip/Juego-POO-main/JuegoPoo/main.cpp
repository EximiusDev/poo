#include <SFML/Graphics.hpp>
#include <string>
#include <SFML/Graphics/Texture.hpp>
#include "Pantalla.h"
#include "TexturePer.h"

#include <vector>
using namespace std;
using namespace sf;

int main(int argc, char *argv[]){

	Pantalla A;
	
	
	A.Run("sfml.png");
	
	
	return 0;
}

