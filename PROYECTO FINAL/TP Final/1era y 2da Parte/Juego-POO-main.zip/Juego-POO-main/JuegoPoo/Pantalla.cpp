#include "Pantalla.h"
#include <SFML/Graphics.hpp>
#include <SFML/Graphics/RenderWindow.hpp>
#include <SFML/Window/VideoMode.hpp>
#include <iostream>
using namespace std;
Pantalla::Pantalla():w(VideoMode(640,480),"Juego De P.O.O") {};

void Pantalla::Run(){
	Event evt;
	while(w.isOpen()) {
		while(w.pollEvent(evt)) {
			if(evt.type == Event::Closed)
				w.close();}
		w.display();
}}

