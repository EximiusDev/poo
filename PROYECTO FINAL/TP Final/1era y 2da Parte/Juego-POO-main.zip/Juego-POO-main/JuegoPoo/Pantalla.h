#ifndef Pantalla_h
#define Pantalla_h
#include <SFML/Graphics.hpp>
#include <SFML/Graphics/RenderWindow.hpp>
using namespace sf;
class Pantalla {
private:
	RenderWindow w;
public:
	Pantalla();
	void Run();
	
};

#endif

