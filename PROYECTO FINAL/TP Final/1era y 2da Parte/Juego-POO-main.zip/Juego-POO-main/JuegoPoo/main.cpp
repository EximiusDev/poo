
#include "Pantalla.h"

using namespace sf;

int main(int argc, char *argv[]){

	Pantalla A;
	A.Run();
	//A.Run();
	
	return 0;
}

