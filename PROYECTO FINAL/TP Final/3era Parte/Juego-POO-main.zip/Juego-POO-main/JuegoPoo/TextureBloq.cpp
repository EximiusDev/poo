#include "TextureBloq.h"

TextureBloq::TextureBloq(vector<vector<TipoBloque>>B) {
	Text.resize(50);
	Spri.resize(50);
	for(int i=0;i<50;i++) { 
		Text[i].resize(50);
		Spri[i].resize(50);
	}
	for(int i=0;i<50;i++) { 
		for(int j=0;j<50;j++) { 
			Text[i][j].loadFromFile(B[i][j].NomBloq());
			Spri[i][j].setTexture(Text[i][j]);
		}
	}
}
Sprite TextureBloq::GeneradorSpr(int a,int b){
	return Spri[a][b];
}
void TextureBloq::PosSpr(int a,int b){
	Spri[a][b].setScale(4,4);
	Spri[a][b].setPosition(b*64,600+a*64);
}
