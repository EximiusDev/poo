#ifndef TEXTUREBLOQ_H
#define TEXTUREBLOQ_H
#include <vector>
#include <SFML/Graphics.hpp>
#include <SFML/Graphics/Texture.hpp>
#include <SFML/Graphics/Sprite.hpp>
#include "TipoBloque.h"
using namespace std;
using namespace sf;

class TextureBloq {

private:
	vector<vector<Texture>>Text;
	vector<vector<Sprite>>Spri;
public:
	TextureBloq(vector<vector<TipoBloque>>B);
	Sprite GeneradorSpr(int a,int b);
	void PosSpr(int a,int b);
};

#endif

