#include "Equipamiento.h"

Equipamiento::Equipamiento() {
	
}

