#include "Personaje.h"

Personaje::Personaje() {
	
}

