#include <SFML/Graphics.hpp>
#include <string>
#include <SFML/Graphics/Texture.hpp>
#include "Pantalla.h"
#include "TexturePer.h"
#include <vector>
#include "GeneracionMundo.h"
#include <iostream>
using namespace std; /// son necesarios ambos namespace sino no funciona
using namespace sf;

int main(int argc, char *argv[]){

	Pantalla A; /// define a A como objeto de tipo Pantalla
	
	
	
	
	/*GeneracionMundo B;
	B.Modificardatos(50,50,20);
		vector<vector<TipoBloque>>B1= B.Ver_Matriz_Bloques();
	for(int i=0;i<100;i++) { 
		for(int j=0;j<100;j++) { 
			cout<<B1[i][j].Verpuntos();
		}
		
	}*/
	A.Run("Excabadora-izq.png"); /// llamo a el obejto A con el metodo Run(para correr el juego) y le paso la imagen a cargar (la imagen del personaje)
	//A.Run("sfml.png");
	
	return 0;
}

