#ifndef PANTALLA_H
#define PANTALLA_H
#include <SFML/Graphics.hpp>
class Pantalla {
private:
	
public:
	Pantalla();
	
};

#endif

