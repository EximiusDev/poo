#include "GeneracionMundo.h"

GeneracionMundo::GeneracionMundo() {
	
}

