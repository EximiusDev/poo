#include "Pantalla.h"

Pantalla::Pantalla() {
	
}

