#ifndef VIDA_H
#define VIDA_H

class Vida {
private:
	int cantVida =3;
public:
	Vida();
	bool pierdeVida();
};

#endif

