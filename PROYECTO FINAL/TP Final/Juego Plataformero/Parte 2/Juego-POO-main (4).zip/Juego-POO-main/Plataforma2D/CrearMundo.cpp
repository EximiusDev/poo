#include "CrearMundo.h"
#include <vector>
#include "Bloques.h"
using namespace std;

CrearMundo::CrearMundo(int cantBloques) {
	
	Tierra1.resize(cantBloques);
	
	y.resize(cantBloques);
	this->cantBloques = cantBloques;
	for(int i=0;i<cantBloques;i++) {
		y[i]=650;
	y[10]=304;
	y[11]=304;
	y[ 15 ]=304;
	y[16]=304;
	y[20]=304;
	y[21]=304;
	y[22]=304;
	y[23]=304;
	y[26]=304;
	y[27]=304;
	Tierra1[i].Start("Tierra2.png");
	Tierra1[i].setPos(i*96,y[i]);

	
	
	
}
}
void CrearMundo::setMov(int x){
	for(int j=0;j<cantBloques;j++) { 
		Tierra1[j].setPos(j*96+x*10,y[j]);
		
		
		
	
	}
}




Sprite CrearMundo::getSpr2(int i){return Tierra1[i].getSpr();}
//FloatRect CrearMundo::Colide(int i){FloatRect r1 =Tierra1[i].getSpr().getGlobalBounds(); return r1;}
Rect<int> CrearMundo::Colide(int i){Rect <int> A(Tierra1[i].getX(),Tierra1[i].getY(),96,96);return A;}
