#include <SFML/Graphics.hpp>
#include "Pantalla.h"
using namespace sf;
using namespace std;

int main(int argc, char *argv[]){
	
	Pantalla Im;
	Im.Start();


	
	
	
	return 0;
}

