#ifndef KEYBOARD_H
#define KEYBOARD_H

class Keyboard {
private:
public:
	Keyboard();

};

#endif

