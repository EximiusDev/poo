#ifndef MOVIMIENTOPERSONAJE_H
#define MOVIMIENTOPERSONAJE_H
#include "TexturePer.h"

class MovimientoPersonaje {
private:
	int x,y;
	
public:
	MovimientoPersonaje(int x1,int y1);
	

};

#endif

