# Proyecto_Final_POO
Temática: Juego   
Libreria: SFML  
Lenguaje: CPP  
Institución: Universidad Nacional Del Litoral  
Facultad: Facultad de Ingeniería y Ciencias Hídricas  

# Sobre el juego
El juego esta basado en el juego "SkyJump" de la aplicacion de celular Pou
Link a la aplicación : https://play.google.com/store/apps/details?id=me.pou.app&hl=es_AR&gl=US

# Screenshots

![Dirt Level](/models/screenshots/dirt.png)

![Ground Level](/models/screenshots/ground.png)

![Space Level](/models/screenshots/space.png)


# Notas
Colaboradores:  
Brisa Antuña  
Nahuel Gareis  
Estudiantes de Ingeniería en Informática
Primer juego
